package com.example.echo.fragments


import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.cleveroad.audiovisualization.AudioVisualization
import com.cleveroad.audiovisualization.DbmHandler
import com.cleveroad.audiovisualization.GLAudioVisualizationView
import com.example.echo.CurrentSongHelper
import com.example.echo.R
import com.example.echo.Songs
import com.example.echo.adapters.FavoriteAdapter
import com.example.echo.databases.EchoDatabase
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.ArrayList


/**
 * A simple [Fragment] subclass.
 *
 */
class SongPlayingFragment : Fragment() {

    /*Here you may wonder that why did we create two objects namely Statified & Staticated respectively
    * These objects are created as the variables and functions will be used from another class
    * Now, the question is why did we make two different objects and not one single object
    * This is because we created the statified object which contains all the variables and
    * the Staticated object which contain all the functions*/
    object Statified{
        var myActivity: Activity?=null

        //This is the media player variable. We would be using this to play/pause the music
        var mediaplayer: MediaPlayer?=null

        //The different variables defined will be used for their respective purposes
        /*Depending on the task they do we name the variables as such so that it gets easier to identify the task they perform*/
        var startTimeText: TextView? = null
        var endTimeText: TextView? = null
        var playPauseImageButton: ImageButton? = null
        var previousImageButton: ImageButton? = null
        var nextImageButton: ImageButton? = null
        var loopImageButton: ImageButton? = null
        var seekbar: SeekBar? = null
        var songArtistView: TextView? = null
        var songTitleView: TextView? = null
        var shuffleImageButton: ImageButton? = null
        var currentPosition: Int = 0
        var fetchSongs: ArrayList<Songs>? = null

        //The current song helper is used to store the details of the current song being played
        var currentSongHelper: CurrentSongHelper? = null
        var audioVisualization: AudioVisualization? = null
        var glView: GLAudioVisualizationView? = null

        //Declaring the variable for handling the favorite button
        var fab: ImageButton? = null
        //Variable for using DB functions
        var favoriteContent: EchoDatabase?= null

        //Sensor Variables
        var mSensorManager: SensorManager?= null
        var mSensorListener: SensorEventListener?= null
        var MY_PREFS_NAME = "ShakeFeature"

        //variable used to update the song time
        var updateSongTime = object: Runnable{
            override fun run() {

                //Retrieving the current time position of the media player
                val getCurrent = Statified.mediaplayer?.getCurrentPosition()

                /*The start time is set to the current position of the song
                * The TimeUnit class changes the units to minutes and milliseconds and applied to the string
                * The %d:%d is used for formatting the time strings as 03:45 so that it appears like time*/
                Statified.startTimeText?.setText(String.format("%d:%d",
                    TimeUnit.MILLISECONDS.toMinutes(getCurrent?.toLong() as Long),
                    TimeUnit.MILLISECONDS.toSeconds(getCurrent?.toLong() as Long) -
                            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(getCurrent?.toLong() as Long))))

                Statified.seekbar?.setProgress(getCurrent?.toInt() as Int)
                /*Since updating the time at each second will take a lot of processing,
                * so we perform this task on different thread using handler*/
                Handler().postDelayed(this, 1000)
            }
        }
    }

    /*Declaring the preferences for the shuffle and loop feature
    * the object is created as we will need them outside the scope of this class*/
    object Staticated{
        var MY_PREFS_SHUFFLE = "Shuffle feature"
        var MY_PREFS_LOOP = "Loop feature"


        //Function to handle the event where the song completes playing
        fun onSongComplete(){

            //If shuffle was on then play a random next song
            if(Statified.currentSongHelper?.isShuffle as Boolean){
                playNext("PlayNextLikeNormalShuffle")
                Statified.currentSongHelper?.isPlaying = true
            }else{

                //If loop was ON, then play the same song again
                if(Statified.currentSongHelper?.isLoop as Boolean){

                    Statified.currentSongHelper?.isPlaying = true
                    val nextSong = Statified.fetchSongs?.get(Statified.currentPosition)
                    Statified.currentSongHelper?.songPath = nextSong?.songData
                    Statified.currentSongHelper?.songTitle = nextSong?.songTitle
                    Statified.currentSongHelper?.songArtist = nextSong?.artist
                    Statified.currentSongHelper?.songId = nextSong?.songID as Long
                    Statified.currentSongHelper?.currentPosition = Statified.currentPosition

                    //updating the text views for title and artist name //updating
                    updateTextView(Statified.currentSongHelper?.songTitle as String, Statified.currentSongHelper?.songArtist as String)
                    Statified.mediaplayer?.reset()
                    try{
                        Statified.mediaplayer?.setDataSource(Statified.myActivity as Context, Uri.parse(nextSong.songData))
                        Statified.mediaplayer?.prepare()
                        Statified.mediaplayer?.start()
                        processInformation(Statified.mediaplayer as MediaPlayer)
                    }catch(e: Exception){
                        e.printStackTrace()
                    }

                }else{
                    //If loop was OFF then normally play the next song
                    playNext("PlayNextNormal")
                    Statified.currentSongHelper?.isPlaying = true
                }
            }
            if(Statified.favoriteContent?.checkIfIdExists(Statified.currentSongHelper?.songId?.toInt() as Int) as Boolean){
                Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_on))
            }else{
                Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_off))
            }
        }

        //Function to update the views of the song and their artist names
        fun updateTextView(songtitle: String, songArtist: String){
            var songTitleUpdated = songtitle
            var songArtistUpdated = songArtist
            if(songtitle.equals("<unknown>", true)){
                songTitleUpdated = "unknown"
            }
            if(songArtist.equals("<unknown>", true)){
                songArtistUpdated = "unknown"
            }
            Statified.songTitleView?.setText(songTitleUpdated)
            Statified.songArtistView?.setText(songArtistUpdated)
        }

        //Function used to update the time
        fun processInformation(mediaPlayer: MediaPlayer){

            //Obtaining the final time
            val finalTime = mediaPlayer.duration

            //Obtaining the current position
            val startTime = mediaPlayer.currentPosition
            Statified.seekbar?.max = finalTime

            //Here we format the time and set it to the start time text
            Statified.startTimeText?.setText(String.format("%d:%d",
                TimeUnit.MILLISECONDS.toMinutes(startTime.toLong()),
                TimeUnit.MILLISECONDS.toSeconds(startTime.toLong()) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(startTime.toLong())))
            )

            //Similar to above is done for the end time text
            Statified.endTimeText?.setText(String.format("%d:%d",
                TimeUnit.MILLISECONDS.toMinutes(finalTime.toLong()),
                TimeUnit.MILLISECONDS.toSeconds(finalTime.toLong()) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(finalTime.toLong())))
            )

            //Seek bar has been assigned this time so that it moves accordingly to the time of song
            Statified.seekbar?.setProgress(startTime)

            //Now this task is synced with the update song time object
            Handler().postDelayed(Statified.updateSongTime, 1000)
        }

        //The playNext() function is used to play the next song
        //The playNext() function is called when we tap on the next button
        fun playNext(check: String){

            //Here we check the value of the string parameter passed
            if(check.equals("PlayNextNormal", true)){

                //If the check string was PlayNextNormal, we normally move on to the next song
                Statified.currentPosition +=  1
            }else if(check.equals("PlayNextLikeNormalShuffle", true)){

                //First we declare a variable and then initialize it to a random object
                val randomObject = Random()

                //Now here we calculate the random number
                /*The nextInt(val n: Int) is used to get a random number between 0(inclusive) and the number passed in this
                  argument(n), exclusive
                  Here we pass the parameter as the length of the list of the songs fetched*/
                /*We add 1 to the size as the length will be one more than size.
                  For example if the size of arrayList is 10, then it has items from 0 to 10, which gives the length as 11*/
                val randomPosition = randomObject.nextInt(Statified.fetchSongs?.size?.plus(1 ) as Int )
                Statified.currentPosition = randomPosition
            }

            //the current position points to the end of the list
            //we then make the current position to 0 as no song will be there
            if(Statified.currentPosition == Statified.fetchSongs?.size){
                Statified.currentPosition = 0
            }
            Statified.currentSongHelper?.isLoop = false

            //Here we get the details of the song which is played as the next song
            //and update the contents of the current song helper
            val nextSong = Statified.fetchSongs?.get(Statified.currentPosition)
            Statified.currentSongHelper?.songPath = nextSong?.songData
            Statified.currentSongHelper?.songTitle = nextSong?.songTitle
            Statified.currentSongHelper?.songArtist = nextSong?.artist
            Statified.currentSongHelper?.songId = nextSong?.songID as Long
            Statified.currentSongHelper?.currentPosition = Statified.currentPosition

            //updating the text views for title and artist name
            updateTextView(Statified.currentSongHelper?.songTitle as String, Statified.currentSongHelper?.songArtist as String)
            //Before playing the song we reset the media player
            Statified.mediaplayer?.reset()
            try{
                Statified.mediaplayer?.setDataSource(Statified.myActivity as Context, Uri.parse(Statified.currentSongHelper?.songPath))
                Statified.mediaplayer?.prepare()
                Statified.mediaplayer?.start()
                processInformation(Statified.mediaplayer as MediaPlayer)
            }catch(e: Exception){
                e.printStackTrace()
            }
            if(Statified.favoriteContent?.checkIfIdExists(Statified.currentSongHelper?.songId?.toInt() as Int) as Boolean){
                Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_on))
            }else{
                Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_off))
            }
        }
    }

    var mAcceleration: Float = 0f
    var mAccelerationCurrent: Float = 0f
    var mAccelerationLast: Float = 0f

    //Similar onCreateView() method of the fragment, which we used for the MainScreenFragment
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_song_playing, container, false)
        setHasOptionsMenu(true)
        activity?.title = "Now Playing"

        //Linking views with their ids
        Statified.seekbar = view?.findViewById(R.id.seekBar)
        Statified.startTimeText = view?.findViewById(R.id.startTime)
        Statified.endTimeText = view?.findViewById(R.id.endTime)
        Statified.playPauseImageButton= view?.findViewById(R.id.playPauseButton)
        Statified.nextImageButton = view?.findViewById(R.id.nextButton)
        Statified.previousImageButton = view?.findViewById(R.id.previousButton)
        Statified.loopImageButton = view?.findViewById(R.id.loopButton)
        Statified.shuffleImageButton = view?.findViewById(R.id.shuffleButton)
        Statified.songArtistView = view?.findViewById(R.id.songArtist)
        Statified.songTitleView = view?.findViewById(R.id.songTitle)
        Statified.glView = view?.findViewById(R.id.visualizer_view)
        Statified.fab = view?.findViewById(R.id.favoriteIcon)

        //Fading the favorite icon
        Statified.fab?.alpha = 0.8f

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Statified.audioVisualization = Statified.glView as AudioVisualization
    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        Statified.myActivity = context as Activity
    }

    override fun onAttach(activity: Activity?) {
        super.onAttach(activity)
        Statified.myActivity = activity
    }

    override fun onResume() {
        super.onResume()
        Statified.audioVisualization?.onResume()

        //Here we register the sensor
        Statified.mSensorManager?.registerListener(Statified.mSensorListener, Statified.mSensorManager?.getDefaultSensor(
            Sensor.TYPE_ACCELEROMETER),SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        Statified.audioVisualization?.onPause()
        super.onPause()

        //When fragment is paused, we remove the sensor to prevent the battery drain
        Statified.mSensorManager?.unregisterListener(Statified.mSensorListener)
    }

    override fun onDestroyView() {
        Statified.audioVisualization?.release()
        super.onDestroyView()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //Sensor service is activate when fragment is created
        Statified.mSensorManager = Statified.myActivity?.getSystemService(Context.SENSOR_SERVICE) as SensorManager

        //Default values
        mAcceleration = 0.0f
        /*We take earth's gravitational value to be default, this will give us good result*/
        mAccelerationCurrent = SensorManager.GRAVITY_EARTH
        mAccelerationLast = SensorManager.GRAVITY_EARTH
        /*Here we call the function*/
        bindShakeListener()
    }

    /*This function is used to create the menu
    * Mainly we create the menu file in XML and inflate it here in this function
    * Note: You might not find the "redirect_icon", kindly use the name "ic_back_to_list"*/
    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        menu?.clear()
        inflater?.inflate(R.menu.song_playing_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onPrepareOptionsMenu(menu: Menu?) {
        super.onPrepareOptionsMenu(menu)
        val item: MenuItem?= menu?.findItem(R.id.action_redirect)
        item?.isVisible = true
        val item2: MenuItem?= menu?.findItem(R.id.action_sort)
        item2?.isVisible = false
    }

    //Here we handle the click event of the menu item
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item?.itemId){
            /*If the id of the item click is action_redirect
            * we navigate back to the list*/
            R.id.action_redirect -> {
                Statified.myActivity?.onBackPressed()
                return false
            }
        }
        return false
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        Statified.favoriteContent = EchoDatabase(Statified.myActivity)
        //Initialising the params of the current song helper object
        Statified.currentSongHelper = CurrentSongHelper()
        Statified.currentSongHelper?.isPlaying = true
        Statified.currentSongHelper?.isShuffle = true
        Statified.currentSongHelper?.isLoop = false

        //Now this is new. Let's see what is all this about
        //These are the variables used for retrieving the Bundle items sent from the main screen
        //Now remember I told you to remember the names of these Bundle items, they will be used here
        var path: String? = null
        var _songTitle: String? = null
        var _songArtist: String? = null
        var songId: Long = 0

        //See that we have used a try catch block here
        /*The reason for doing so is that, it may happen that the bundle object does not have these in it and the app may crash
        * So in order to prevent the crash we use try-catch block. This block is known as the error-handling block*/
        try{
            //path is retrieved using the same key (path) which was used to send it
            path = arguments?.getString("path")

            //song title is retrieved with its key songTitle
            _songTitle = arguments?.getString("songTitle")

            //song artist with the key songArtist
            _songArtist = arguments?.getString("songArtist")

            //song id with the key SongId
            songId = arguments?.getInt("SongId")?.toLong() as Long

            //Here we fetch the received bundle data for current position and the list of all songs
            Statified.currentPosition = arguments?.getInt("songPosition") as Int
            Statified.fetchSongs = arguments?.getParcelableArrayList("songData")

            /*Now store the song details to the current song helper object so that they can be used later*/
            Statified.currentSongHelper?.songPath = path
            Statified.currentSongHelper?.songTitle = _songTitle
            Statified.currentSongHelper?.songArtist = _songArtist
            Statified.currentSongHelper?.songId = songId
            Statified.currentSongHelper?.currentPosition = Statified.currentPosition

            Staticated.updateTextView(Statified.currentSongHelper?.songTitle as String, Statified.currentSongHelper?.songArtist as String)
        }catch(e: Exception){
            e.printStackTrace()
        }

        //Here we check whether we came to the song playing fragment via tapping on a song or by bottom bar
        val fromFavBottomBar = arguments?.get("FavBottomBar") as? String
        val fromBottomBar = arguments?.get("BottomBar") as? String
        if(fromFavBottomBar !=null){
            //If we come via bottom bar then the already playing media player object is used
            Statified.mediaplayer = FavouriteFragment.Statified.mediaPlayer
        }else if(fromBottomBar != null){
            Statified.mediaplayer = MainScreenFragment.Statified.mediaPlayer
        } else {
            //Else we use the default way
            //here we initialise the media player object
            Statified.mediaplayer = MediaPlayer()
            Statified.mediaplayer?.reset()

            //Here we tell the media player object that we would be streaming the music
            Statified.mediaplayer?.setAudioStreamType(AudioManager.STREAM_MUSIC)
            try {

                //The data source set the song to the media player object
                Statified.mediaplayer?.setDataSource(Statified.myActivity as Context, Uri.parse(path))

                //Before playing the music we prepare the media player for playback
                Statified.mediaplayer?.prepare()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            //If all the above goes well we start the music using the start() method
            Statified.mediaplayer?.start()
        }
        Staticated.processInformation(Statified.mediaplayer as MediaPlayer)

        if(Statified.currentSongHelper?.isPlaying as Boolean){
            Statified.playPauseImageButton?.setBackgroundResource(R.drawable.pause_icon)
        }else{
            Statified.playPauseImageButton?.setBackgroundResource(R.drawable.play_icon)
        }

        //Handling the event when media player finishes a song
        Statified.mediaplayer?.setOnCompletionListener{
            Staticated.onSongComplete()
        }

        //Making the click actions function
        clickHandler()
        val visualizationHandler = DbmHandler.Factory.newVisualizerHandler(Statified.myActivity as Context, 0)
        Statified.audioVisualization?.linkTo(visualizationHandler)

        /*Now we want that when if user has turned shuffle or loop ON, then these settings should persist
          even if the app is restarted after closing
        * This is done with the help of Shared Preferences
        * Shared preferences are capable of storing small amount of data in the form of key-value pair*/
        //Here we initialize the preferences for shuffle in a private mode
        //Private mode is chosen so that other apps are not able to read preferences apart from our app
        var prefsForShuffle = Statified.myActivity?.getSharedPreferences(Staticated.MY_PREFS_SHUFFLE, Context.MODE_PRIVATE)

        //Here we extract the value of preferences and check if shuffle was ON or not
        var isShuffleAllowed = prefsForShuffle?.getBoolean("feature", false)
        if(isShuffleAllowed as Boolean){

            //if shuffle was found activated, then we change the icon color and turn loop OFF
            Statified.currentSongHelper?.isShuffle = true
            Statified.currentSongHelper?.isLoop = false
            Statified.shuffleImageButton?.setBackgroundResource(R.drawable.shuffle_icon)
            Statified.loopImageButton?.setBackgroundResource((R.drawable.loop_white_icon))
        }else{
            //Else default is set
            Statified.currentSongHelper?.isShuffle = false
            Statified.shuffleImageButton?.setBackgroundResource(R.drawable.shuffle_white_icon)
        }

        //Similar to the shuffle we check the value for loop activation
        var prefsForLoop = Statified.myActivity?.getSharedPreferences(Staticated.MY_PREFS_LOOP, Context.MODE_PRIVATE)

        //Here we extract the value of preferences and check if loop was ON or not
        var isLoopAllowed = prefsForLoop?.getBoolean("feature", false)
        if(isLoopAllowed as Boolean){

            //If loop was activated we change the icon color and shuffle is turned OFF
            Statified.currentSongHelper?.isShuffle = false
            Statified.currentSongHelper?.isLoop = true
            Statified.shuffleImageButton?.setBackgroundResource(R.drawable.shuffle_white_icon)
            Statified.loopImageButton?.setBackgroundResource((R.drawable.loop_icon))
        }else{
            Statified.currentSongHelper?.isLoop = false
            Statified.loopImageButton?.setBackgroundResource(R.drawable.loop_white_icon)
        }

        /*Here we check that if the song playing is favorite, then we show a red colored heart indicating favorite else only the heart boundary
        * This action is performed whenever a new song is played, hence this will done in the playNext(), playPrevious() and onSongComplete() methods*/
        if(Statified.favoriteContent?.checkIfIdExists(Statified.currentSongHelper?.songId?.toInt() as Int) as Boolean){
            Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_on))
        }else{
            Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_off))
        }
    }

    /*A new click handler function is created to handle all the click functions in the song playing fragment*/
    fun clickHandler(){

        //Here we handle the click of the favorite icon
        //When the icon was clicked, if it was red in color i.e. a favorite song then we remove the song from favorites
        Statified.fab?.setOnClickListener({
            if(Statified.favoriteContent?.checkIfIdExists(Statified.currentSongHelper?.songId?.toInt() as Int) as Boolean){
                Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_off))
                Statified.favoriteContent?.deleteFavourite(Statified.currentSongHelper?.songId?.toInt() as Int)
                Toast.makeText(Statified.myActivity, "Removed from favorites", Toast.LENGTH_SHORT).show()
            }else{

                //If the song was not favorite, we then add it to the favorites using the method we made in our database
                Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_on))
                Statified.favoriteContent?.storeAsFavorite(Statified.currentSongHelper?.songId?.toInt(), Statified.currentSongHelper?.songArtist,
                    Statified.currentSongHelper?.songTitle, Statified.currentSongHelper?.songPath)
                Toast.makeText(Statified.myActivity, "Added to favorites", Toast.LENGTH_SHORT).show()
            }
        })
        //The implementation will be taught in the coming topics
        Statified.shuffleImageButton?.setOnClickListener({

            //Initializing the shared preferences in private mode
            //edit() used so that we can overwrite the preferences
            var editorShuffle = Statified.myActivity?.getSharedPreferences(Staticated.MY_PREFS_SHUFFLE, Context.MODE_PRIVATE)?.edit()
            var editorLoop = Statified.myActivity?.getSharedPreferences(Staticated.MY_PREFS_LOOP, Context.MODE_PRIVATE)?.edit()
            if(Statified.currentSongHelper?.isShuffle as Boolean){
                Statified.shuffleImageButton?.setBackgroundResource(R.drawable.shuffle_white_icon)
                Statified.currentSongHelper?.isShuffle = false

                /*If shuffle was activated previously, then we deactivate it*/
                /*The putBoolean() method is used for saving the boolean value against the key which is feature here*/
                //Now the preferences against the block shuffle feature will have a key: feature and its value: false
                editorShuffle?.putBoolean("feature", false)
                editorShuffle?.apply()
            }else{
                Statified.currentSongHelper?.isLoop = false
                Statified.currentSongHelper?.isShuffle = true
                Statified.loopImageButton?.setBackgroundResource(R.drawable.loop_white_icon)
                Statified.shuffleImageButton?.setBackgroundResource(R.drawable.shuffle_icon)

                    //Else shuffle is activated and if loop was activated then loop is deactivated
                editorShuffle?.putBoolean("feature", true)
                editorShuffle?.apply()


                editorLoop?.putBoolean("feature", false)
                editorLoop?.apply()
            }
        })

        //Here we set the click listener to next button
        Statified.nextImageButton?.setOnClickListener({

            //We set the player to be playing by setting isPlaying to be true
            Statified.currentSongHelper?.isPlaying = true
            Statified.playPauseImageButton?.setBackgroundResource(R.drawable.pause_icon)

            //First we check if the shuffle button was enabled or not
            if(Statified.currentSongHelper?.isShuffle as Boolean){

                //If yes, then we play the next song randomly
                /*The check string is passed as the PlayNextLikeNormalShuffle
                 which plays the random next song*/
                Staticated.playNext("PlayNextLikeNormalShuffle")
            }else{

                //If shuffle was not enabled then we normally play the next song
                //The check string passed is the PlayNextNormal which serves the purpose
                Staticated.playNext("PlayNextNormal")
            }
        })
        //Here we set the click listener to the  ext button
        Statified.previousImageButton?.setOnClickListener({

            //We set the player to be playing by setting isPlaying to be true
            Statified.currentSongHelper?.isPlaying = true

            //First we check if the loop is on or not
            if(Statified.currentSongHelper?.isLoop as Boolean){

                //If the loop was on we turn it off
                Statified.loopImageButton?.setBackgroundResource(R.drawable.loop_white_icon)
            }

            /*After all is done we play the previous song using the playPrevious() function*/
            playPrevious()
        })
        //Here we handle the click on the loop button
        Statified.loopImageButton?.setOnClickListener({

            //The operation on preferences is completely analogous to shuffle, no addition is there
            var editorShuffle = Statified.myActivity?.getSharedPreferences(Staticated.MY_PREFS_SHUFFLE, Context.MODE_PRIVATE)?.edit()
            var editorLoop = Statified.myActivity?.getSharedPreferences(Staticated.MY_PREFS_LOOP, Context.MODE_PRIVATE)?.edit()

            //if loop was enabled we turn it off and vice versa
            if(Statified.currentSongHelper?.isLoop as Boolean){
                Statified.currentSongHelper?.isLoop = false

                //we change the color of the icon
                Statified.loopImageButton?.setBackgroundResource(R.drawable.loop_white_icon)
                editorLoop?.putBoolean("feature", false)
                editorLoop?.apply()

            }else{
                //If loop was not enabled when tapped, we enable if and make the isLoop to true
                Statified.currentSongHelper?.isLoop = true

                //Loop and Shuffle won't work together so we put shuffle false irrespective of the whether it was on or not
                Statified.currentSongHelper?.isShuffle = false

                //Loop button color changed to mark it ON
                Statified.loopImageButton?.setBackgroundResource(R.drawable.loop_icon)

                //Changing the shuffle button to white, no matter which color it was earlier
                Statified.shuffleImageButton?.setBackgroundResource(R.drawable.shuffle_white_icon)
                editorShuffle?.putBoolean("feature", false)
                editorShuffle?.apply()
                editorLoop?.putBoolean("feature", true)
                editorLoop?.apply()
            }
        })

        //Here we handle the click event on the play/pause button
        Statified.playPauseImageButton?.setOnClickListener({

            //if the song is already playing then play/pause button is tapped
            //then we pause the media player and also change the button to play button
            if(Statified.mediaplayer?.isPlaying as Boolean){
                Statified.mediaplayer?.pause()
                Statified.currentSongHelper?.isPlaying = false
                Statified.playPauseImageButton?.setBackgroundResource(R.drawable.play_icon)

                //If the song was not playing then, we start the music player and change the image to pause icon
            }else{
                Statified.mediaplayer?.start()
                Statified.currentSongHelper?.isPlaying = true
                Statified.playPauseImageButton?.setBackgroundResource(R.drawable.pause_icon)
            }
        })
    }

    //The function playPrevious() is used to play the previous song again
    fun playPrevious(){

        //Decreasing the current position by 1 to get the position of the previous song
        Statified.currentPosition -= 1

        //If the current position becomes less than 1, we make it 0 as there is no index as -1
        if(Statified.currentPosition == -1){
            Statified.currentPosition = 0
        }
        if(Statified.currentSongHelper?.isPlaying as Boolean){
            Statified.playPauseImageButton?.setBackgroundResource(R.drawable.pause_icon)
        }else{
            Statified.playPauseImageButton?.setBackgroundResource(R.drawable.play_icon)
        }
        Statified.currentSongHelper?.isLoop = false
        val nextSong = Statified.fetchSongs?.get(Statified.currentPosition)
        Statified.currentSongHelper?.songPath = nextSong?.songData
        Statified.currentSongHelper?.songTitle = nextSong?.songTitle
        Statified.currentSongHelper?.songArtist = nextSong?.artist
        Statified.currentSongHelper?.songId = nextSong?.songID as Long
        Statified.currentSongHelper?.currentPosition = Statified.currentPosition

        //updating the text views for title and artist name
        Staticated.updateTextView(Statified.currentSongHelper?.songTitle as String, Statified.currentSongHelper?.songArtist as String)
        Statified.mediaplayer?.reset()
        try{
            Statified.mediaplayer?.setDataSource(Statified.myActivity as Context, Uri.parse(Statified.currentSongHelper?.songPath))
            Statified.mediaplayer?.prepare()
            Statified.mediaplayer?.start()
            Staticated.processInformation(Statified.mediaplayer as MediaPlayer)
        }catch(e: Exception){
            e.printStackTrace()
        }
        if(Statified.favoriteContent?.checkIfIdExists(Statified.currentSongHelper?.songId?.toInt() as Int) as Boolean){
            Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_on))
        }else{
            Statified.fab?.setImageDrawable(ContextCompat.getDrawable(Statified.myActivity as Context, R.drawable.favorite_off))
        }
    }

    /*This function handles the shake events in order to change the songs when we shake the phone*/
    fun bindShakeListener(){

        /*The sensor listener has two methods used for its implementation i.e. OnAccuracyChanged() and OnSensorChanged*/
        Statified.mSensorListener = object: SensorEventListener{
            override fun onAccuracyChanged(p0: Sensor?, p1: Int) {
                //We do not need to check or work with the accuracy changes for the sensor
            }

            override fun onSensorChanged(p0: SensorEvent) {
                /*We need this OnSensorChanged function
                * this function is called when there is a new sensor event
                * The sensor event has 3 dimensions i.e. the x, y and z in which the changes can occur*/
                val x = p0.values[0]
                val y = p0.values[1]
                val z = p0.values[2]

                //Now lets see how we calculate the changes in the acceleration
                //Now we shook the phone so the current acceleration will be the first to start with
                mAccelerationLast = mAccelerationCurrent

                /*Since we could have moved the phone in any direction, we calculate the Euclidean distance to get the normalized distance*/
                mAccelerationCurrent = Math.sqrt(((x*x + y*y + z*z).toDouble())).toFloat()

                //Delta gives the change in acceleration
                val delta = mAccelerationCurrent - mAccelerationLast

                /*Here we calculate the lower filter
                * The written below is a formula to get it*/
                mAcceleration = mAcceleration + 0.9f + delta

                /*We obtain a real number of acceleration
                * and we check if the acceleration was noticeable, considering 12 here*/
                if(mAcceleration > 12){

                    //If the accel was greater than 12 we change the song, given the fact our shake to change was active
                    val prefs = Statified.myActivity?.getSharedPreferences(Statified.MY_PREFS_NAME, Context.MODE_PRIVATE)
                    val isAllowed = prefs?.getBoolean("feature", false)
                    if(isAllowed as Boolean){
                        Staticated.playNext("PlayNextNormal")
                    }
                }
            }

        }
    }

}
